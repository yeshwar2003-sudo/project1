# Bulk Import Guide - Adding Multiple Donors at Once

This guide shows you how to import donor data in bulk (many people at once).

---

## ✅ Yes, I Can Help!

Send me your donor data and I'll help you import it. Here are the methods available:

---

## 📋 Data Format Required

Please provide your data in **one of these formats**:

### Option 1: JSON Array (Preferred)
```json
[
  {
    "fullName": "Rahul Sharma",
    "email": "rahul.sharma@example.com",
    "phone": "9876543210",
    "bloodType": "O+",
    "age": "28",
    "weight": "65",
    "city": "Andheri",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400058",
    "lastDonation": "2024-11-15",
    "medicalConditions": "",
    "availability": "anytime"
  },
  {
    "fullName": "Priya Patel",
    "email": "priya@example.com",
    "phone": "9876543211",
    "bloodType": "A+",
    "age": "26",
    "weight": "55",
    "city": "Bandra",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400050",
    "availability": "weekends"
  }
]
```

### Option 2: CSV Format
```csv
fullName,email,phone,bloodType,age,weight,city,district,state,pincode,lastDonation,medicalConditions,availability
Rahul Sharma,rahul@example.com,9876543210,O+,28,65,Andheri,Mumbai,Maharashtra,400058,2024-11-15,,anytime
Priya Patel,priya@example.com,9876543211,A+,26,55,Bandra,Mumbai,Maharashtra,400050,,,weekends
```

### Option 3: Excel/Google Sheets
- Just share the spreadsheet with columns matching the fields above
- I'll convert it to the right format

---

## 🎯 Import Methods

Choose based on your setup:

### Method 1: Browser Console (Easiest - localStorage)

**When to use:** Testing, no deployment needed

**Steps:**
1. Open your app in browser
2. Press F12 to open Developer Tools
3. Go to Console tab
4. Paste this code:

```javascript
// Your donor data
const donors = [
  {
    fullName: "Rahul Sharma",
    email: "rahul@example.com",
    phone: "9876543210",
    bloodType: "O+",
    age: "28",
    weight: "65",
    city: "Andheri",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400058",
    availability: "anytime"
  }
  // ... more donors
];

// Import script
const DONORS_KEY = "lifelink_donors";
const existing = JSON.parse(localStorage.getItem(DONORS_KEY) || '[]');
donors.forEach((donor, i) => {
  existing.push({
    id: `donor:${Date.now() + i}:${Math.random().toString(36).substr(2, 9)}`,
    ...donor,
    registeredAt: new Date().toISOString()
  });
});
localStorage.setItem(DONORS_KEY, JSON.stringify(existing));
console.log(`✅ Imported ${donors.length} donors!`);
```

5. Press Enter
6. ✅ Done! Go to `/find-donors` to see them

---

### Method 2: TypeScript Script (Database Mode)

**When to use:** After deploying Edge Functions, for database import

**Steps:**

1. Open `scripts/bulk-import-donors.ts`

2. Replace the `donorsToImport` array with your data

3. Run the script:
```bash
npx ts-node scripts/bulk-import-donors.ts
```

4. ✅ Done! Data saved to database

---

### Method 3: API Calls (Programmatic)

**When to use:** Integrating with other systems

```typescript
const API_URL = "https://wlmjimdrkiqohudnurlw.supabase.co/functions/v1/make-server-07d11c75/donors";
const API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";

async function importDonor(donor) {
  const response = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${API_KEY}`
    },
    body: JSON.stringify(donor)
  });
  return response.json();
}

// Import all donors
for (const donor of donors) {
  const result = await importDonor(donor);
  console.log(result.success ? '✅' : '❌', donor.fullName);
}
```

---

### Method 4: I'll Do It For You! 

**Just give me the data and I'll:**

1. Validate the format
2. Check for duplicates
3. Generate the import code
4. Run it for you
5. Verify all data imported

**What I need from you:**
- Your donor data (any format above)
- Which method you prefer (localStorage or database)
- Any special requirements

---

## 🔒 Important: Privacy & Security

### Before importing real data:

⚠️ **Warning:** This app stores personal health information!

- [ ] **Get consent** from donors to store their data
- [ ] **Verify data accuracy** - wrong blood type can be dangerous
- [ ] **Secure the data** - Consider if this should be in a database with encryption
- [ ] **Comply with laws** - Check local data protection regulations
- [ ] **Don't share** API keys or database credentials

### For testing only:
- ✅ Use fake/test data
- ✅ Use your own info
- ✅ Use friends who gave permission

### For production:
- ⚠️ This demo app is NOT HIPAA-compliant
- ⚠️ Use proper healthcare software for real medical data
- ⚠️ Consider legal implications

---

## 📊 Field Descriptions

| Field | Required | Format | Example |
|-------|----------|--------|---------|
| fullName | ✅ Yes | Text | "Rahul Sharma" |
| email | ✅ Yes | Email | "rahul@example.com" |
| phone | ✅ Yes | 10 digits | "9876543210" |
| bloodType | ✅ Yes | A+, A-, B+, B-, AB+, AB-, O+, O- | "O+" |
| age | ✅ Yes | 18-65 | "28" |
| weight | ✅ Yes | Kg (min 45) | "65" |
| city | ✅ Yes | Text | "Andheri" |
| district | ✅ Yes | Text | "Mumbai" |
| state | ✅ Yes | Indian state | "Maharashtra" |
| pincode | ✅ Yes | 6 digits | "400058" |
| lastDonation | ❌ Optional | YYYY-MM-DD | "2024-11-15" |
| medicalConditions | ❌ Optional | Text | "None" or "" |
| availability | ✅ Yes | anytime, weekdays, weekends, emergency | "anytime" |

---

## 🧪 Testing Your Import

After importing, test it:

### 1. Check Count
```javascript
// In browser console
const donors = JSON.parse(localStorage.getItem('lifelink_donors'));
console.log(`Total donors: ${donors.length}`);
```

### 2. Search for Someone
1. Go to `/find-donors`
2. Select a blood type from your data
3. Enter a city from your data
4. Click Search
5. ✅ Should see the donor(s)

### 3. View All Data
```javascript
// In browser console
console.table(JSON.parse(localStorage.getItem('lifelink_donors')));
```

---

## 🐛 Troubleshooting

### Import failed?
- Check JSON is valid (use jsonlint.com)
- Ensure all required fields present
- Check phone numbers are 10 digits
- Check pincodes are 6 digits
- Verify blood types are correct

### Data not showing in search?
- Clear browser cache
- Hard refresh (Ctrl+F5)
- Check console for errors
- Verify data is in localStorage

### Want to re-import?
```javascript
// Clear existing data first
localStorage.removeItem('lifelink_donors');
// Then import again
```

---

## 📝 Example: Complete Import

Here's a complete example with 5 donors:

```json
[
  {
    "fullName": "Rahul Sharma",
    "email": "rahul.sharma@example.com",
    "phone": "9876543210",
    "bloodType": "O+",
    "age": "28",
    "weight": "65",
    "city": "Andheri",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400058",
    "lastDonation": "2024-11-15",
    "medicalConditions": "",
    "availability": "anytime"
  },
  {
    "fullName": "Priya Patel",
    "email": "priya.patel@example.com",
    "phone": "9876543211",
    "bloodType": "A+",
    "age": "26",
    "weight": "55",
    "city": "Bandra",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400050",
    "lastDonation": "",
    "medicalConditions": "",
    "availability": "weekends"
  },
  {
    "fullName": "Amit Kumar",
    "email": "amit.kumar@example.com",
    "phone": "9876543212",
    "bloodType": "B+",
    "age": "32",
    "weight": "70",
    "city": "Powai",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400076",
    "lastDonation": "2024-10-20",
    "medicalConditions": "",
    "availability": "anytime"
  },
  {
    "fullName": "Sneha Reddy",
    "email": "sneha.reddy@example.com",
    "phone": "9876543213",
    "bloodType": "AB+",
    "age": "24",
    "weight": "52",
    "city": "Juhu",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400049",
    "lastDonation": "",
    "medicalConditions": "",
    "availability": "emergency"
  },
  {
    "fullName": "Vikram Singh",
    "email": "vikram.singh@example.com",
    "phone": "9876543214",
    "bloodType": "O-",
    "age": "35",
    "weight": "75",
    "city": "Malad",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400064",
    "lastDonation": "2024-09-05",
    "medicalConditions": "",
    "availability": "weekdays"
  }
]
```

---

## 🚀 Ready to Import?

**Option 1: Send me your data**
Just paste your donor list in the chat and I'll create a custom import script for you!

**Option 2: DIY**
Use Method 1 (Browser Console) - it's the easiest!

**Option 3: Let me code it**
Give me the data, I'll write the exact code you need to run.

---

## ❓ Questions?

**Q: How many can I import at once?**  
A: Unlimited! But localStorage has ~5-10MB limit (thousands of donors).

**Q: Can I import from Excel?**  
A: Yes! Just give me the Excel file or CSV export.

**Q: Will it duplicate donors?**  
A: No duplicate checking by default. Clear before re-importing.

**Q: Can I update existing donors?**  
A: Need to clear and re-import, or I can write update logic.

**Q: Does it work with database mode?**  
A: Yes! All methods work with both localStorage and database.

---

**Ready when you are! Just give me your donor data and I'll help you import it.** 🩸❤️

---

**Last Updated:** May 6, 2026
