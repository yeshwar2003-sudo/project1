// Bulk Import to localStorage - Browser-based
// Open your app in browser and paste this into console

interface Donor {
  fullName: string;
  email: string;
  phone: string;
  bloodType: string;
  age: string;
  weight: string;
  city: string;
  district: string;
  state: string;
  pincode: string;
  lastDonation?: string;
  medicalConditions?: string;
  availability: string;
}

// ====================================================================
// PASTE YOUR DONOR DATA HERE
// ====================================================================

const donorsToImport: Donor[] = [
  {
    fullName: "Rahul Sharma",
    email: "rahul.sharma@example.com",
    phone: "9876543210",
    bloodType: "O+",
    age: "28",
    weight: "65",
    city: "Andheri",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400058",
    lastDonation: "2024-11-15",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Priya Patel",
    email: "priya.patel@example.com",
    phone: "9876543211",
    bloodType: "A+",
    age: "26",
    weight: "55",
    city: "Bandra",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400050",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekends"
  },
  // Add more donors here...
];

// ====================================================================
// IMPORT LOGIC (Don't modify)
// ====================================================================

const DONORS_KEY = "lifelink_donors";

function bulkImportToLocalStorage() {
  console.log(`\n🚀 Starting localStorage import of ${donorsToImport.length} donors...\n`);

  // Get existing donors
  const existing = JSON.parse(localStorage.getItem(DONORS_KEY) || '[]');
  const startCount = existing.length;

  // Import new donors
  let imported = 0;
  donorsToImport.forEach((donor, index) => {
    const newDonor = {
      id: `donor:${Date.now() + index}:${Math.random().toString(36).substr(2, 9)}`,
      ...donor,
      registeredAt: new Date().toISOString()
    };
    existing.push(newDonor);
    imported++;
    console.log(`✅ [${index + 1}/${donorsToImport.length}] Imported: ${donor.fullName}`);
  });

  // Save to localStorage
  localStorage.setItem(DONORS_KEY, JSON.stringify(existing));

  console.log(`\n📊 Import Complete!`);
  console.log(`✅ Imported: ${imported} new donors`);
  console.log(`📈 Total donors: ${existing.length} (was ${startCount})`);
  console.log(`\n💡 Tip: Go to /find-donors to see them!`);
}

// Export function for use
export { bulkImportToLocalStorage, donorsToImport };

// Auto-run if in browser console
if (typeof window !== 'undefined') {
  console.log(`
╔════════════════════════════════════════════════════╗
║  LifeLink - Bulk Import to localStorage           ║
╚════════════════════════════════════════════════════╝

To import donors:
1. Edit the donorsToImport array above
2. Run: bulkImportToLocalStorage()

To view current donors:
  JSON.parse(localStorage.getItem('lifelink_donors'))

To clear all donors:
  localStorage.removeItem('lifelink_donors')
  `);
}
