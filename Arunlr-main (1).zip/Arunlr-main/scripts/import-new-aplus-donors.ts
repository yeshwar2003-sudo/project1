// Import 10 new A+ blood donors
// Data provided by user - adding to localStorage

const newAPlusDonors = [
  {
    fullName: "Sunitha C",
    email: "sunitha.c@example.com",
    phone: "9448281375",
    bloodType: "A+",
    age: "30",
    weight: "55",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560001",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Arun J Kumar",
    email: "arun.kumar@example.com",
    phone: "9845488113",
    bloodType: "A+",
    age: "32",
    weight: "70",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560002",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Sandeep Devaki",
    email: "sandeep.devaki@example.com",
    phone: "8121269312",
    bloodType: "A+",
    age: "28",
    weight: "68",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560003",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Suman S H",
    email: "suman.sh@example.com",
    phone: "9343754518",
    bloodType: "A+",
    age: "29",
    weight: "65",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560004",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Ali Mohammed",
    email: "ali.mohammed@example.com",
    phone: "9008066308",
    bloodType: "A+",
    age: "35",
    weight: "72",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560005",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Sanoj Thomas",
    email: "sanoj.thomas@example.com",
    phone: "9886772233",
    bloodType: "A+",
    age: "31",
    weight: "67",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560006",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Rakesh Sharan R",
    email: "rakesh.sharan@example.com",
    phone: "8123020307",
    bloodType: "A+",
    age: "33",
    weight: "73",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560007",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Pradeep",
    email: "pradeep@example.com",
    phone: "9972144992",
    bloodType: "A+",
    age: "27",
    weight: "64",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560008",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Priya Vignesh",
    email: "priya.vignesh@example.com",
    phone: "8971093958",
    bloodType: "A+",
    age: "26",
    weight: "52",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560009",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Mahesh Dhinge",
    email: "mahesh.dhinge@example.com",
    phone: "9741255223",
    bloodType: "A+",
    age: "34",
    weight: "69",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560010",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  }
];

// Import to localStorage
const DONORS_KEY = "lifelink_donors";

function importNewDonors() {
  console.log("\n🚀 Importing 10 new A+ blood donors...\n");

  // Get existing donors
  const existing = JSON.parse(localStorage.getItem(DONORS_KEY) || '[]');
  const startCount = existing.length;

  // Add new donors with IDs
  newAPlusDonors.forEach((donor, index) => {
    const newDonor = {
      id: `donor:${Date.now() + index}:${Math.random().toString(36).substr(2, 9)}`,
      ...donor,
      registeredAt: new Date().toISOString()
    };
    existing.push(newDonor);
    console.log(`✅ [${index + 1}/10] Imported: ${donor.fullName} - ${donor.phone}`);
  });

  // Save to localStorage
  localStorage.setItem(DONORS_KEY, JSON.stringify(existing));

  console.log(`\n📊 Import Complete!`);
  console.log(`✅ Imported: 10 new A+ donors`);
  console.log(`📈 Total donors: ${existing.length} (was ${startCount})`);
  console.log(`\n💡 Go to /find-donors and search for A+ in Bangalore!`);
}

// Export for use
export { importNewDonors, newAPlusDonors };

// Browser console instructions
if (typeof window !== 'undefined') {
  console.log(`
╔════════════════════════════════════════════════════╗
║  Import 10 New A+ Blood Donors                     ║
╚════════════════════════════════════════════════════╝

To import these donors, run:
  importNewDonors()
  `);
}
