// Bulk Import Script for Blood Donors
// Usage: Run this script to import multiple donors at once

import { projectId, publicAnonKey } from "../utils/supabase/info";

// ====================================================================
// PASTE YOUR DONOR DATA HERE
// ====================================================================

const donorsToImport = [
  // Example format - Replace with your actual data
  {
    fullName: "Rahul Sharma",
    email: "rahul.sharma@example.com",
    phone: "9876543210",
    bloodType: "O+",
    age: "28",
    weight: "65",
    city: "Andheri",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400058",
    lastDonation: "2024-11-15",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Priya Patel",
    email: "priya.patel@example.com",
    phone: "9876543211",
    bloodType: "A+",
    age: "26",
    weight: "55",
    city: "Bandra",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400050",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekends"
  },
  // Add more donors here...
];

// ====================================================================
// IMPORT LOGIC (Don't modify below this line)
// ====================================================================

const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-07d11c75/donors`;

interface ImportResult {
  success: number;
  failed: number;
  errors: Array<{ donor: string; error: string }>;
}

async function importDonor(donor: any): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(donor),
    });

    const result = await response.json();

    if (result.success) {
      return { success: true };
    } else {
      return { success: false, error: result.error };
    }
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

async function bulkImport(): Promise<ImportResult> {
  console.log(`\n🚀 Starting bulk import of ${donorsToImport.length} donors...\n`);

  const result: ImportResult = {
    success: 0,
    failed: 0,
    errors: []
  };

  for (let i = 0; i < donorsToImport.length; i++) {
    const donor = donorsToImport[i];
    console.log(`[${i + 1}/${donorsToImport.length}] Importing ${donor.fullName}...`);

    const importResult = await importDonor(donor);

    if (importResult.success) {
      console.log(`✅ Success: ${donor.fullName}`);
      result.success++;
    } else {
      console.log(`❌ Failed: ${donor.fullName} - ${importResult.error}`);
      result.failed++;
      result.errors.push({
        donor: donor.fullName,
        error: importResult.error || "Unknown error"
      });
    }

    // Small delay to avoid overwhelming the API
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  console.log(`\n📊 Import Complete!`);
  console.log(`✅ Successful: ${result.success}`);
  console.log(`❌ Failed: ${result.failed}`);

  if (result.errors.length > 0) {
    console.log(`\n❌ Errors:`);
    result.errors.forEach(err => {
      console.log(`  - ${err.donor}: ${err.error}`);
    });
  }

  return result;
}

// Run the import
bulkImport().catch(console.error);
