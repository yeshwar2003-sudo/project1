import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Global error handler
app.onError((err, c) => {
  console.error("Global error handler caught:", err);
  return c.json({
    success: false,
    error: err.message || "Internal server error"
  }, 500);
});

// Health check endpoint
app.get("/make-server-07d11c75/health", (c) => {
  return c.json({ status: "ok" });
});

// Register a new blood donor
app.post("/make-server-07d11c75/donors", async (c) => {
  try {
    // Check if request has body
    const contentType = c.req.header("Content-Type");
    if (!contentType || !contentType.includes("application/json")) {
      return c.json({
        success: false,
        error: "Content-Type must be application/json"
      }, 400);
    }

    // Get raw body text first to handle empty bodies
    const bodyText = await c.req.text();
    if (!bodyText || bodyText.trim() === "") {
      return c.json({
        success: false,
        error: "Request body is empty"
      }, 400);
    }

    // Parse JSON
    let donorData;
    try {
      donorData = JSON.parse(bodyText);
    } catch (parseError) {
      return c.json({
        success: false,
        error: `Invalid JSON: ${parseError.message}`
      }, 400);
    }

    const donorId = `donor:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;

    const donor = {
      id: donorId,
      ...donorData,
      registeredAt: new Date().toISOString(),
    };

    await kv.set(donorId, donor);

    console.log(`Donor registered successfully: ${donorId}`);
    return c.json({ success: true, donor, message: "Donor registered successfully" });
  } catch (error) {
    console.error(`Error registering donor:`, error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get all donors or filter by blood type, state, city, and pincode
app.get("/make-server-07d11c75/donors", async (c) => {
  try {
    const bloodType = c.req.query("bloodType") || "";
    const state = c.req.query("state") || "";
    const city = c.req.query("city") || "";
    const pincode = c.req.query("pincode") || "";

    console.log(`Searching donors - bloodType: ${bloodType}, state: ${state}, city: ${city}, pincode: ${pincode}`);

    const allDonors = await kv.getByPrefix("donor:");

    if (!allDonors || allDonors.length === 0) {
      console.log("No donors found in database");
      return c.json({ success: true, donors: [] });
    }

    let filteredDonors = allDonors;

    if (bloodType) {
      filteredDonors = filteredDonors.filter(
        (donor) => donor.bloodType === bloodType
      );
    }

    if (state) {
      filteredDonors = filteredDonors.filter(
        (donor) => donor.state?.toLowerCase() === state.toLowerCase()
      );
    }

    if (city) {
      const cityLower = city.toLowerCase();
      filteredDonors = filteredDonors.filter(
        (donor) =>
          donor.city?.toLowerCase().includes(cityLower) ||
          donor.district?.toLowerCase().includes(cityLower)
      );
    }

    if (pincode) {
      filteredDonors = filteredDonors.filter(
        (donor) => donor.pincode?.includes(pincode)
      );
    }

    console.log(`Retrieved ${filteredDonors.length} donors`);
    return c.json({ success: true, donors: filteredDonors });
  } catch (error) {
    console.error(`Error retrieving donors:`, error);
    return c.json({ success: false, error: error.message || "Failed to retrieve donors" }, 500);
  }
});

// Submit a blood request
app.post("/make-server-07d11c75/blood-requests", async (c) => {
  try {
    // Check if request has body
    const contentType = c.req.header("Content-Type");
    if (!contentType || !contentType.includes("application/json")) {
      return c.json({
        success: false,
        error: "Content-Type must be application/json"
      }, 400);
    }

    // Get raw body text first to handle empty bodies
    const bodyText = await c.req.text();
    if (!bodyText || bodyText.trim() === "") {
      return c.json({
        success: false,
        error: "Request body is empty"
      }, 400);
    }

    // Parse JSON
    let requestData;
    try {
      requestData = JSON.parse(bodyText);
    } catch (parseError) {
      return c.json({
        success: false,
        error: `Invalid JSON: ${parseError.message}`
      }, 400);
    }

    const requestId = `request:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;

    const bloodRequest = {
      id: requestId,
      ...requestData,
      submittedAt: new Date().toISOString(),
      status: "pending",
    };

    await kv.set(requestId, bloodRequest);

    console.log(`Blood request submitted successfully: ${requestId}`);
    return c.json({ success: true, request: bloodRequest, message: "Blood request submitted successfully" });
  } catch (error) {
    console.error(`Error submitting blood request:`, error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get all blood requests
app.get("/make-server-07d11c75/blood-requests", async (c) => {
  try {
    console.log("Fetching all blood requests");

    const allRequests = await kv.getByPrefix("request:");

    if (!allRequests || allRequests.length === 0) {
      console.log("No blood requests found in database");
      return c.json({ success: true, requests: [] });
    }

    console.log(`Retrieved ${allRequests.length} blood requests`);
    return c.json({ success: true, requests: allRequests });
  } catch (error) {
    console.error(`Error retrieving blood requests:`, error);
    return c.json({ success: false, error: error.message || "Failed to retrieve blood requests" }, 500);
  }
});

Deno.serve(app.fetch);