# Quick Start Guide - LifeLink Blood Donation Network

## 🚨 Important: Deploy Edge Functions First!

If you're seeing **"Failed to fetch"** errors, you need to deploy the Supabase Edge Functions first.

### Quick Deploy (Choose One)

**Option A: Via Supabase CLI** ⭐ Recommended
```bash
npm install -g supabase
supabase login
supabase functions deploy make-server-07d11c75 --project-ref wlmjimdrkiqohudnurlw
```

**Option B: Via Figma Make**
1. Open Settings in Figma Make
2. Go to Supabase section
3. Click "Deploy Edge Functions"

**Option C: Via Supabase Dashboard**
1. Go to https://supabase.com/dashboard/project/wlmjimdrkiqohudnurlw
2. Navigate to Edge Functions
3. Deploy `make-server-07d11c75` function

### Verify Deployment

Open this URL in your browser:
```
https://wlmjimdrkiqohudnurlw.supabase.co/functions/v1/make-server-07d11c75/health
```

✅ **Success:** You should see `{"status":"ok"}`  
❌ **Failed:** See [DEPLOYMENT_INSTRUCTIONS.md](./DEPLOYMENT_INSTRUCTIONS.md)

---

## 📋 What Works Now

After deployment, all features will work:

✅ **Donor Registration** (`/become-donor`)
- Register new blood donors
- Save to database permanently
- Email confirmation

✅ **Find Donors** (`/find-donors`)
- Search by blood type
- Filter by location (city/pincode)
- View donor contact details

✅ **Request Blood** (`/request-blood`)
- Submit urgent blood requests
- Track request status
- Notify matching donors (future)

✅ **Home Page** (`/`)
- View statistics
- Learn about the platform
- Quick access to all features

---

## 🧪 Test the Application

### 1. Register a Test Donor

1. Go to `/become-donor`
2. Fill in the form with test data:
   - Name: Test Donor
   - Email: test@example.com
   - Phone: 9876543210
   - Blood Type: O+
   - Location: Mumbai, Maharashtra
3. Submit the form
4. ✅ You should see success message

### 2. Search for the Donor

1. Go to `/find-donors`
2. Select Blood Type: O+
3. Enter Location: Mumbai
4. Click Search
5. ✅ You should see the test donor in results

### 3. Submit a Test Request

1. Go to `/request-blood`
2. Fill in the blood request form
3. Submit
4. ✅ You should see success confirmation

---

## 🐛 Troubleshooting

### Error: "Failed to fetch"
➡️ See [DEPLOYMENT_INSTRUCTIONS.md](./DEPLOYMENT_INSTRUCTIONS.md)

### Error: "API Error: 404"
➡️ Function name mismatch. Check deployment name.

### Error: "API Error: 500"
➡️ Check Supabase Edge Function logs in dashboard.

### Form Validation Issues
➡️ See [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

### Database Not Saving Data
➡️ Check browser console for detailed error messages.

**Full troubleshooting guide:** [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

---

## 📚 Documentation

- **[PROJECT_REPORT.md](./PROJECT_REPORT.md)** - Complete project documentation
- **[README.md](./README.md)** - Developer guide
- **[TECHNICAL_DOCUMENTATION.md](./TECHNICAL_DOCUMENTATION.md)** - Technical details
- **[DEPLOYMENT_INSTRUCTIONS.md](./DEPLOYMENT_INSTRUCTIONS.md)** - How to deploy
- **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)** - Fix common issues

---

## 🚀 Going Live

### Before Production

1. ✅ Deploy Edge Functions
2. ✅ Test all forms and features
3. ✅ Verify data persistence
4. ✅ Test on mobile devices
5. ✅ Review security settings
6. ✅ Set up monitoring

### Security Checklist

⚠️ **Important:** This is a demo app. For production:

- [ ] Enable RLS (Row Level Security) in Supabase
- [ ] Add user authentication
- [ ] Implement data encryption
- [ ] Set up rate limiting
- [ ] Add CAPTCHA to forms
- [ ] Review HIPAA/compliance requirements
- [ ] Set up error monitoring
- [ ] Configure backup strategy

---

## 📊 Project Statistics

- **Components:** 15+
- **Pages:** 6
- **API Endpoints:** 4
- **Blood Types:** 8
- **Indian States:** 36
- **Lines of Code:** 3,500+

---

## 🆘 Need Help?

1. **Check Documentation:** Start with troubleshooting guide
2. **Browser Console:** Press F12 to see detailed errors
3. **Supabase Logs:** Check Edge Function logs in dashboard
4. **GitHub Issues:** [Report bugs here]
5. **Email Support:** support@lifelink.in

---

## ✨ Next Steps

After everything is working:

1. Test with real donors (friends/family)
2. Gather feedback
3. Implement Phase 2 features
4. Add authentication
5. Set up notifications
6. Launch publicly

**Good luck saving lives! 🩸❤️**

---

**Version:** 1.0  
**Last Updated:** May 6, 2026
