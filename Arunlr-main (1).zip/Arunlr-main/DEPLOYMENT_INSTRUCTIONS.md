# Deploying Supabase Edge Functions

## The Issue

You're seeing "Failed to fetch" because the Supabase Edge Functions need to be deployed from the Supabase Dashboard.

## Solution: Deploy Edge Functions

### Step 1: Access Supabase Dashboard

1. Go to https://supabase.com/dashboard
2. Sign in to your account
3. Select your project: `wlmjimdrkiqohudnurlw`

### Step 2: Deploy the Edge Function

**Option A: Using Supabase CLI (Recommended)**

1. Install Supabase CLI:
```bash
npm install -g supabase
```

2. Login to Supabase:
```bash
supabase login
```

3. Link your project:
```bash
supabase link --project-ref wlmjimdrkiqohudnurlw
```

4. Deploy the edge function:
```bash
supabase functions deploy make-server-07d11c75
```

**Option B: Using Supabase Dashboard**

1. Go to **Edge Functions** in the left sidebar
2. Click **Deploy new function**
3. Name it: `make-server-07d11c75`
4. Copy the content from `/supabase/functions/server/index.tsx`
5. Click **Deploy**

### Step 3: Verify Deployment

Test the health endpoint in your browser:
```
https://wlmjimdrkiqohudnurlw.supabase.co/functions/v1/make-server-07d11c75/health
```

You should see:
```json
{"status":"ok"}
```

## Alternative: Use Mock Data (For Testing)

If you can't deploy right now, I can set up mock data for testing the frontend.

## After Deployment

Once deployed, the app will work correctly:
- ✅ Donor registration will save to database
- ✅ Blood requests will be stored
- ✅ Find donors will return real results

## Need Help?

If deployment fails, check:
1. Supabase project is active
2. You have deploy permissions
3. Edge Functions are enabled on your plan
4. No syntax errors in server code
