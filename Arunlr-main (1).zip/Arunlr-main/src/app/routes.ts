import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { FindDonors } from "./pages/FindDonors";
import { BecomeDonor } from "./pages/BecomeDonor";
import { RequestBlood } from "./pages/RequestBlood";
import { HowItWorks } from "./pages/HowItWorks";
import { BulkImport } from "./pages/BulkImport";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/find-donors",
    Component: FindDonors,
  },
  {
    path: "/become-donor",
    Component: BecomeDonor,
  },
  {
    path: "/request-blood",
    Component: RequestBlood,
  },
  {
    path: "/how-it-works",
    Component: HowItWorks,
  },
  {
    path: "/bulk-import",
    Component: BulkImport,
  },
  {
    path: "*",
    Component: NotFound,
  },
]);
