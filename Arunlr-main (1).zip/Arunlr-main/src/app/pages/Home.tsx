import { Link } from "react-router";
import { Heart, Users, MapPin, Clock, ArrowRight, Droplet, Shield, Zap } from "lucide-react";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function Home() {
  const stats = [
    { label: "Active Donors", value: "30+", icon: Users },
    { label: "Blood Types", value: "8", icon: Heart },
    { label: "Cities Covered", value: "10+", icon: MapPin },
    { label: "Avg Response Time", value: "< 2hrs", icon: Clock },
  ];

  const features = [
    {
      icon: Zap,
      title: "Instant Matching",
      description: "Our algorithm instantly connects you with compatible donors in your area.",
    },
    {
      icon: Shield,
      title: "Verified Donors",
      description: "All donors are verified and screened to ensure safety and reliability.",
    },
    {
      icon: MapPin,
      title: "Location-Based",
      description: "Find donors nearby to reduce response time in critical situations.",
    },
    {
      icon: Droplet,
      title: "All Blood Types",
      description: "We maintain a diverse network covering all blood types including rare ones.",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-red-50 to-pink-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-red-100 text-red-700 px-4 py-2 rounded-full mb-6">
                <Heart className="w-4 h-4 fill-red-700" />
                <span className="text-sm font-semibold">Saving Lives Together</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Every Drop Counts,{" "}
                <span className="text-red-600">Every Life Matters</span>
              </h1>
              <p className="text-lg text-gray-600 mb-8">
                Join our network of life-savers. Connect with blood donors instantly
                and help save lives in your community.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/request-blood"
                  className="inline-flex items-center justify-center gap-2 bg-red-600 text-white px-8 py-4 rounded-lg hover:bg-red-700 transition-colors font-semibold"
                >
                  Request Blood
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/become-donor"
                  className="inline-flex items-center justify-center gap-2 bg-white text-red-600 px-8 py-4 rounded-lg border-2 border-red-600 hover:bg-red-50 transition-colors font-semibold"
                >
                  Become a Donor
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1615461066159-fea0960485d5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9vZCUyMGRvbmF0aW9uJTIwbWVkaWNhbCUyMGhlYWx0aGNhcmV8ZW58MXx8fHwxNzczMTE2MTk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Blood donation"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg hidden md:block">
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Heart className="w-6 h-6 text-green-600 fill-green-600" />
                  </div>
                  <div>
                    <div className="font-bold text-2xl text-gray-900">24/7</div>
                    <div className="text-sm text-gray-600">Available</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-12 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <Icon className="w-8 h-8 text-red-600 mx-auto mb-3" />
                  <div className="font-bold text-3xl text-gray-900 mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose LifeLink?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our platform makes blood donation simple, secure, and efficient
              for both donors and recipients.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="bg-red-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-red-600" />
                  </div>
                  <h3 className="font-semibold text-xl text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-pink-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Make a Difference?
          </h2>
          <p className="text-lg text-red-100 mb-8 max-w-2xl mx-auto">
            Join thousands of donors who are saving lives every day. Your contribution
            can make all the difference.
          </p>
          <Link
            to="/become-donor"
            className="inline-flex items-center gap-2 bg-white text-red-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
          >
            Start Saving Lives Today
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
