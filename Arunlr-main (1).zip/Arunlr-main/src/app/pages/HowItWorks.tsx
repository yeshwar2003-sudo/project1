import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { UserPlus, Search, Phone, Droplet, CheckCircle, Clock } from "lucide-react";

export function HowItWorks() {
  const forDonors = [
    {
      icon: UserPlus,
      title: "Register as Donor",
      description: "Sign up with your details including blood type, location, and contact information.",
      step: "01",
    },
    {
      icon: Clock,
      title: "Get Notified",
      description: "Receive notifications when someone in your area needs your blood type.",
      step: "02",
    },
    {
      icon: Phone,
      title: "Respond & Connect",
      description: "Choose to help and connect directly with the person in need.",
      step: "03",
    },
    {
      icon: Droplet,
      title: "Donate & Save Lives",
      description: "Visit the hospital or blood bank at your convenience and make a difference.",
      step: "04",
    },
  ];

  const forRecipients = [
    {
      icon: Phone,
      title: "Submit Request",
      description: "Fill out a simple form with patient details, blood type needed, and urgency level.",
      step: "01",
    },
    {
      icon: Search,
      title: "Auto-Matching",
      description: "Our system instantly finds compatible donors in your area and notifies them.",
      step: "02",
    },
    {
      icon: Phone,
      title: "Get Connected",
      description: "Compatible donors will contact you directly or through our platform.",
      step: "03",
    },
    {
      icon: CheckCircle,
      title: "Coordinate Donation",
      description: "Work with the donor to arrange the blood donation at your specified hospital.",
      step: "04",
    },
  ];

  const faqs = [
    {
      question: "Is this service free?",
      answer: "Yes, LifeLink is completely free for both donors and recipients. We believe saving lives should be accessible to everyone.",
    },
    {
      question: "How quickly can I find a donor?",
      answer: "Average response time is under 2 hours for urgent requests. However, this depends on donor availability in your area.",
    },
    {
      question: "Is my information safe?",
      answer: "Absolutely. We use industry-standard encryption and never share your information without consent. Your privacy is our priority.",
    },
    {
      question: "Can I donate if I've donated recently?",
      answer: "You can donate whole blood every 56 days (8 weeks). Our system tracks your last donation date to ensure safety.",
    },
    {
      question: "What if there are no donors in my area?",
      answer: "We'll expand the search radius and continuously notify new donors who join the platform in your region.",
    },
    {
      question: "Do I need to go to a specific hospital?",
      answer: "No, donors can donate at any certified blood bank or the hospital specified by the recipient.",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-red-50 to-pink-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            How LifeLink Works
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our platform makes blood donation simple and efficient. Here's how we connect
            donors with people in need.
          </p>
        </div>
      </section>

      {/* For Donors */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              For Donors
            </h2>
            <p className="text-lg text-gray-600">
              Four simple steps to become a life-saver
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {forDonors.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="relative">
                  <div className="bg-white p-6 rounded-xl shadow-sm border-2 border-gray-100 hover:border-red-200 transition-colors h-full">
                    <div className="absolute -top-4 -left-4 bg-red-600 text-white font-bold text-xl w-12 h-12 rounded-full flex items-center justify-center">
                      {item.step}
                    </div>
                    <div className="bg-red-100 w-14 h-14 rounded-lg flex items-center justify-center mb-4 mt-2">
                      <Icon className="w-7 h-7 text-red-600" />
                    </div>
                    <h3 className="font-semibold text-xl text-gray-900 mb-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* For Recipients */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              For Recipients
            </h2>
            <p className="text-lg text-gray-600">
              Getting help is quick and straightforward
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {forRecipients.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="relative">
                  <div className="bg-white p-6 rounded-xl shadow-sm border-2 border-gray-100 hover:border-red-200 transition-colors h-full">
                    <div className="absolute -top-4 -left-4 bg-red-600 text-white font-bold text-xl w-12 h-12 rounded-full flex items-center justify-center">
                      {item.step}
                    </div>
                    <div className="bg-red-100 w-14 h-14 rounded-lg flex items-center justify-center mb-4 mt-2">
                      <Icon className="w-7 h-7 text-red-600" />
                    </div>
                    <h3 className="font-semibold text-xl text-gray-900 mb-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Safety & Verification */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Safety & Verification
            </h2>
            <p className="text-lg text-gray-600">
              Your safety is our top priority
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-red-50 to-pink-50 p-8 rounded-xl">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-sm">
                <CheckCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-xl text-gray-900 mb-3">
                Verified Donors
              </h3>
              <p className="text-gray-700">
                All donors undergo verification to ensure authenticity and reliability
                of information provided.
              </p>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-pink-50 p-8 rounded-xl">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-sm">
                <CheckCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-xl text-gray-900 mb-3">
                Health Screening
              </h3>
              <p className="text-gray-700">
                Donors must meet health criteria and eligibility requirements before
                being added to the network.
              </p>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-pink-50 p-8 rounded-xl">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-sm">
                <CheckCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-xl text-gray-900 mb-3">
                Privacy Protected
              </h3>
              <p className="text-gray-700">
                Your personal information is encrypted and only shared with your explicit
                consent.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-gray-600">
              Got questions? We've got answers
            </p>
          </div>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
              >
                <h3 className="font-semibold text-lg text-gray-900 mb-2">
                  {faq.question}
                </h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-pink-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-lg text-red-100 mb-8 max-w-2xl mx-auto">
            Join our community today and make a real difference in people's lives.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/become-donor"
              className="inline-flex items-center justify-center bg-white text-red-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
            >
              Become a Donor
            </a>
            <a
              href="/request-blood"
              className="inline-flex items-center justify-center bg-transparent text-white px-8 py-4 rounded-lg border-2 border-white hover:bg-white/10 transition-colors font-semibold"
            >
              Request Blood
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
