import { useState } from "react";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { Upload, CheckCircle2, AlertCircle, Database, HardDrive } from "lucide-react";
import { saveDonor } from "../utils/localStorage";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";

export function BulkImport() {
  const [jsonData, setJsonData] = useState("");
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<{
    success: number;
    failed: number;
    errors: string[];
  } | null>(null);
  const [mode, setMode] = useState<"localStorage" | "database">("localStorage");

  const exampleData = `[
  {
    "fullName": "Rahul Sharma",
    "email": "rahul@example.com",
    "phone": "9876543210",
    "bloodType": "O+",
    "age": "28",
    "weight": "65",
    "city": "Andheri",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400058",
    "availability": "anytime"
  },
  {
    "fullName": "Priya Patel",
    "email": "priya@example.com",
    "phone": "9876543211",
    "bloodType": "A+",
    "age": "26",
    "weight": "55",
    "city": "Bandra",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400050",
    "availability": "weekends"
  }
]`;

  const importToDatabase = async (donor: any) => {
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-07d11c75/donors`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(donor),
      }
    );
    const result = await response.json();
    return result.success;
  };

  const handleImport = async () => {
    setImporting(true);
    setResult(null);

    try {
      const donors = JSON.parse(jsonData);

      if (!Array.isArray(donors)) {
        throw new Error("Data must be a JSON array");
      }

      let success = 0;
      let failed = 0;
      const errors: string[] = [];

      for (const donor of donors) {
        try {
          if (mode === "localStorage") {
            saveDonor(donor);
            success++;
          } else {
            const imported = await importToDatabase(donor);
            if (imported) {
              success++;
            } else {
              failed++;
              errors.push(`${donor.fullName}: API returned failure`);
            }
          }
        } catch (err: any) {
          failed++;
          errors.push(`${donor.fullName || "Unknown"}: ${err.message}`);
        }
      }

      setResult({ success, failed, errors });
    } catch (err: any) {
      setResult({
        success: 0,
        failed: 1,
        errors: [`Invalid JSON: ${err.message}`],
      });
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center bg-red-100 p-3 rounded-full mb-4">
            <Upload className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Bulk Import Donors
          </h1>
          <p className="text-lg text-gray-600">
            Import multiple donors at once using JSON data
          </p>
        </div>

        {/* Mode Selection */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Import Mode</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <button
              onClick={() => setMode("localStorage")}
              className={`p-4 border-2 rounded-lg transition-all ${
                mode === "localStorage"
                  ? "border-red-600 bg-red-50"
                  : "border-gray-300 hover:border-gray-400"
              }`}
            >
              <div className="flex items-center gap-3">
                <HardDrive
                  className={`w-6 h-6 ${
                    mode === "localStorage" ? "text-red-600" : "text-gray-600"
                  }`}
                />
                <div className="text-left">
                  <div
                    className={`font-semibold ${
                      mode === "localStorage" ? "text-red-600" : "text-gray-900"
                    }`}
                  >
                    localStorage Mode
                  </div>
                  <div className="text-sm text-gray-600">Browser storage (instant)</div>
                </div>
              </div>
            </button>

            <button
              onClick={() => setMode("database")}
              className={`p-4 border-2 rounded-lg transition-all ${
                mode === "database"
                  ? "border-red-600 bg-red-50"
                  : "border-gray-300 hover:border-gray-400"
              }`}
            >
              <div className="flex items-center gap-3">
                <Database
                  className={`w-6 h-6 ${
                    mode === "database" ? "text-red-600" : "text-gray-600"
                  }`}
                />
                <div className="text-left">
                  <div
                    className={`font-semibold ${
                      mode === "database" ? "text-red-600" : "text-gray-900"
                    }`}
                  >
                    Database Mode
                  </div>
                  <div className="text-sm text-gray-600">
                    Supabase (requires deployment)
                  </div>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Import Form */}
        <div className="bg-white rounded-xl shadow-sm p-6 md:p-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Paste JSON Data
          </h2>

          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Donor Data (JSON Array)
              </label>
              <button
                onClick={() => setJsonData(exampleData)}
                className="text-sm text-red-600 hover:text-red-700"
              >
                Load Example
              </button>
            </div>
            <textarea
              value={jsonData}
              onChange={(e) => setJsonData(e.target.value)}
              rows={15}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent font-mono text-sm"
              placeholder={exampleData}
            />
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-yellow-900 mb-1">
                  Important: Privacy & Consent
                </p>
                <p className="text-xs text-yellow-800">
                  Only import data with proper consent. This app is for demo purposes.
                  For real medical data, use HIPAA-compliant systems.
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={handleImport}
            disabled={importing || !jsonData.trim()}
            className="w-full bg-red-600 text-white px-8 py-4 rounded-lg hover:bg-red-700 transition-colors font-semibold disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {importing ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                Importing...
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                Import Donors
              </>
            )}
          </button>
        </div>

        {/* Results */}
        {result && (
          <div className="mt-6 bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Import Results
            </h2>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <div>
                    <div className="text-2xl font-bold text-green-900">
                      {result.success}
                    </div>
                    <div className="text-sm text-green-700">Imported Successfully</div>
                  </div>
                </div>
              </div>

              {result.failed > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <AlertCircle className="w-6 h-6 text-red-600" />
                    <div>
                      <div className="text-2xl font-bold text-red-900">
                        {result.failed}
                      </div>
                      <div className="text-sm text-red-700">Failed</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {result.errors.length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-sm font-semibold text-red-900 mb-2">Errors:</p>
                <ul className="text-xs text-red-800 space-y-1">
                  {result.errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mt-4 text-center">
              <a
                href="/find-donors"
                className="inline-block bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors font-semibold"
              >
                View Imported Donors
              </a>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="font-semibold text-blue-900 mb-3">
            Required Fields Format:
          </h3>
          <div className="text-sm text-blue-800 space-y-1">
            <p>• <strong>fullName</strong>: Text (e.g., "Rahul Sharma")</p>
            <p>• <strong>email</strong>: Valid email (e.g., "rahul@example.com")</p>
            <p>• <strong>phone</strong>: 10 digits (e.g., "9876543210")</p>
            <p>• <strong>bloodType</strong>: A+, A-, B+, B-, AB+, AB-, O+, O-</p>
            <p>• <strong>age</strong>: 18-65</p>
            <p>• <strong>weight</strong>: Kg, minimum 45</p>
            <p>• <strong>city, district, state</strong>: Location details</p>
            <p>• <strong>pincode</strong>: 6 digits</p>
            <p>• <strong>availability</strong>: anytime, weekdays, weekends, emergency</p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
