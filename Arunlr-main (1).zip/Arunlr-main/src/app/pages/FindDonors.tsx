import { useState } from "react";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { Search, MapPin, Phone, Mail, Clock, AlertCircle } from "lucide-react";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { searchDonors } from "../utils/localStorage";

interface Donor {
  id: string;
  fullName: string;
  bloodType: string;
  city: string;
  district?: string;
  state: string;
  pincode?: string;
  lastDonation?: string;
  availability: string;
  phone: string;
  email: string;
  age?: string;
  weight?: string;
  medicalConditions?: string;
  registeredAt?: string;
}

// Mock data removed - now using real database data

export function FindDonors() {
  const [bloodType, setBloodType] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const [searched, setSearched] = useState(false);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [usingLocalStorage, setUsingLocalStorage] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    setLoading(true);
    setError("");
    setUsingLocalStorage(false);

    // Use localStorage directly (API-first commented out until Edge Function is deployed)
    try {
      const localDonors = searchDonors(bloodType, state, city, pincode);
      console.log("✅ Donors fetched from localStorage:", localDonors);
      setUsingLocalStorage(true);
      setDonors(localDonors);
      setLoading(false);
    } catch (localError: any) {
      console.error("Search failed:", localError);
      setError(`Failed to search donors: ${localError.message}`);
      setDonors([]);
      setLoading(false);
    }

    // Uncomment below to enable API mode once Edge Function is deployed
    /*
    try {
      const params = new URLSearchParams();
      if (bloodType) params.append("bloodType", bloodType);
      if (state) params.append("state", state);
      if (city) params.append("city", city);
      if (pincode) params.append("pincode", pincode);

      const apiUrl = `https://${projectId}.supabase.co/functions/v1/make-server-07d11c75/donors?${params.toString()}`;
      console.log("Attempting API call:", apiUrl);

      const response = await fetch(apiUrl, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${publicAnonKey}`,
        },
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const result = await response.json();

      if (result.success) {
        console.log("✅ Donors fetched from database:", result.donors);
        setDonors(result.donors);
      } else {
        throw new Error(result.error || "Failed to fetch donors");
      }
    } catch (apiError: any) {
      console.warn("API failed, using localStorage fallback:", apiError.message);

      // Fallback to localStorage
      try {
        const localDonors = searchDonors(bloodType, state, city, pincode);
        console.log("✅ Donors fetched from localStorage:", localDonors);
        setUsingLocalStorage(true);
        setDonors(localDonors);
      } catch (localError: any) {
        console.error("LocalStorage also failed:", localError);
        setError(`Failed to search donors: ${localError.message}`);
        setDonors([]);
      }
    } finally {
      setLoading(false);
    }
    */
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Find Blood Donors
          </h1>
          <p className="text-lg text-gray-600">
            Search for available donors in your area
          </p>
        </div>

        {/* Search Form */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Blood Type *
                </label>
                <select
                  value={bloodType}
                  onChange={(e) => setBloodType(e.target.value)}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  <option value="">Select blood type</option>
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  State
                </label>
                <select
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  <option value="">Select state</option>
                  <option value="Andhra Pradesh">Andhra Pradesh</option>
                  <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                  <option value="Assam">Assam</option>
                  <option value="Bihar">Bihar</option>
                  <option value="Chhattisgarh">Chhattisgarh</option>
                  <option value="Goa">Goa</option>
                  <option value="Gujarat">Gujarat</option>
                  <option value="Haryana">Haryana</option>
                  <option value="Himachal Pradesh">Himachal Pradesh</option>
                  <option value="Jharkhand">Jharkhand</option>
                  <option value="Karnataka">Karnataka</option>
                  <option value="Kerala">Kerala</option>
                  <option value="Madhya Pradesh">Madhya Pradesh</option>
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Manipur">Manipur</option>
                  <option value="Meghalaya">Meghalaya</option>
                  <option value="Mizoram">Mizoram</option>
                  <option value="Nagaland">Nagaland</option>
                  <option value="Odisha">Odisha</option>
                  <option value="Punjab">Punjab</option>
                  <option value="Rajasthan">Rajasthan</option>
                  <option value="Sikkim">Sikkim</option>
                  <option value="Tamil Nadu">Tamil Nadu</option>
                  <option value="Telangana">Telangana</option>
                  <option value="Tripura">Tripura</option>
                  <option value="Uttar Pradesh">Uttar Pradesh</option>
                  <option value="Uttarakhand">Uttarakhand</option>
                  <option value="West Bengal">West Bengal</option>
                  <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                  <option value="Chandigarh">Chandigarh</option>
                  <option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                  <option value="Ladakh">Ladakh</option>
                  <option value="Lakshadweep">Lakshadweep</option>
                  <option value="Puducherry">Puducherry</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  City
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="Enter city"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pincode
                </label>
                <input
                  type="text"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  pattern="[0-9]{6}"
                  maxLength={6}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="6-digit pincode"
                />
              </div>
            </div>
            <div className="flex justify-center">
              <button
                type="submit"
                disabled={loading}
                className="bg-red-600 text-white px-8 py-3 rounded-lg hover:bg-red-700 transition-colors font-semibold flex items-center justify-center gap-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                <Search className="w-5 h-5" />
                {loading ? "Searching..." : "Search Donors"}
              </button>
            </div>
          </form>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
            <p className="text-sm text-red-800">{error}</p>
          </div>
        )}

        {/* Results */}
        {searched && !loading && (
          <div>
            {donors.length > 0 ? (
              <>
                <div className="mb-4">
                  <p className="text-gray-600">
                    Found <span className="font-semibold text-gray-900">{donors.length}</span> donors
                    matching your criteria
                  </p>
                  {usingLocalStorage && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-3">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-blue-800">
                          <strong>Local Storage Mode:</strong> Showing donors saved in your browser.
                          Deploy Supabase Edge Functions to use database.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="grid gap-6">
                  {donors.map((donor) => (
                    <div
                      key={donor.id}
                      className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow"
                    >
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-start gap-4">
                            <div className="bg-red-100 text-red-600 font-bold text-xl w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0">
                              {donor.bloodType}
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold text-xl text-gray-900 mb-2">
                                {donor.fullName}
                              </h3>
                              <div className="grid sm:grid-cols-2 gap-2 text-sm text-gray-600">
                                <div className="flex items-center gap-2">
                                  <MapPin className="w-4 h-4 text-gray-400" />
                                  <span>
                                    {donor.city}{donor.district ? `, ${donor.district}` : ""}, {donor.state}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Clock className="w-4 h-4 text-gray-400" />
                                  <span>{donor.availability === "anytime" ? "Available Anytime" : donor.availability}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Phone className="w-4 h-4 text-gray-400" />
                                  <span>{donor.phone}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Mail className="w-4 h-4 text-gray-400" />
                                  <span>{donor.email}</span>
                                </div>
                              </div>
                              {donor.lastDonation && (
                                <div className="mt-2">
                                  <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                                    Last donated: {new Date(donor.lastDonation).toLocaleDateString()}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <a
                            href={`tel:${donor.phone}`}
                            className="bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors font-semibold"
                          >
                            Contact Donor
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                <div className="text-gray-400 mb-4">
                  <Search className="w-16 h-16 mx-auto" />
                </div>
                <h3 className="font-semibold text-xl text-gray-900 mb-2">
                  No Donors Found
                </h3>
                <p className="text-gray-600">
                  We couldn't find any donors matching your criteria. Try adjusting
                  your search parameters.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
