import { Mail, Phone, MapPin } from "lucide-react";
import { Link } from "react-router";
import logoImage from "../../imports/image.png";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img
                src={logoImage}
                alt="LifeLink Logo"
                className="h-10 w-10 object-cover rounded-lg"
              />
              <span className="font-bold text-xl text-white">LifeLink</span>
            </div>
            <p className="text-sm text-gray-400">
              Connecting donors with those in need, one drop at a time.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/find-donors" className="hover:text-red-500 transition-colors">
                  Find Donors
                </Link>
              </li>
              <li>
                <Link to="/become-donor" className="hover:text-red-500 transition-colors">
                  Become a Donor
                </Link>
              </li>
              <li>
                <Link to="/request-blood" className="hover:text-red-500 transition-colors">
                  Request Blood
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" className="hover:text-red-500 transition-colors">
                  How It Works
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-semibold text-white mb-4">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  About Blood Donation
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  Eligibility Criteria
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-red-500 transition-colors">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-white mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-500" />
                <span>1800-XXX-XXXX (Toll Free)</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-red-500" />
                <span>support@lifelink.in</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-red-500 mt-0.5" />
                <span>New Delhi, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-sm text-center text-gray-400">
          <p>&copy; 2026 LifeLink Blood Donation Network. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
