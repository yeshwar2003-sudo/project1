import { RouterProvider } from "react-router";
import { router } from "./routes";
import { useEffect } from "react";
import { loadSampleData } from "./utils/sampleData";

export default function App() {
  useEffect(() => {
    console.log("✅ App mounted successfully");

    // Load sample donor data on first visit
    try {
      loadSampleData();
    } catch (error) {
      console.error('Failed to load sample data:', error);
    }
  }, []);

  return <RouterProvider router={router} />;
}
