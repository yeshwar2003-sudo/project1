// Temporary localStorage implementation for testing
// Replace with real API calls once Supabase Edge Functions are deployed

export interface Donor {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  bloodType: string;
  city: string;
  district: string;
  state: string;
  pincode: string;
  age: string;
  weight: string;
  lastDonation?: string;
  medicalConditions?: string;
  availability: string;
  registeredAt: string;
}

export interface BloodRequest {
  id: string;
  patientName: string;
  contactName: string;
  contactPhone: string;
  contactEmail: string;
  bloodType: string;
  unitsNeeded: string;
  urgency: string;
  hospital: string;
  city: string;
  district: string;
  state: string;
  pincode: string;
  reason: string;
  additionalInfo?: string;
  submittedAt: string;
  status: string;
}

const DONORS_KEY = "lifelink_donors";
const REQUESTS_KEY = "lifelink_requests";

// Donor operations
export const saveDonor = (donorData: Omit<Donor, "id" | "registeredAt">): Donor => {
  const donors = getDonors();
  const donor: Donor = {
    id: `donor:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`,
    ...donorData,
    registeredAt: new Date().toISOString(),
  };
  donors.push(donor);
  localStorage.setItem(DONORS_KEY, JSON.stringify(donors));
  return donor;
};

export const getDonors = (): Donor[] => {
  const stored = localStorage.getItem(DONORS_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const searchDonors = (
  bloodType?: string,
  state?: string,
  city?: string,
  pincode?: string
): Donor[] => {
  let donors = getDonors();

  if (bloodType) {
    donors = donors.filter(donor => donor.bloodType === bloodType);
  }

  if (state) {
    donors = donors.filter(donor =>
      donor.state?.toLowerCase() === state.toLowerCase()
    );
  }

  if (city) {
    const cityLower = city.toLowerCase();
    donors = donors.filter(donor =>
      donor.city?.toLowerCase().includes(cityLower) ||
      donor.district?.toLowerCase().includes(cityLower)
    );
  }

  if (pincode) {
    donors = donors.filter(donor =>
      donor.pincode?.includes(pincode)
    );
  }

  return donors;
};

// Blood request operations
export const saveBloodRequest = (
  requestData: Omit<BloodRequest, "id" | "submittedAt" | "status">
): BloodRequest => {
  const requests = getBloodRequests();
  const request: BloodRequest = {
    id: `request:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`,
    ...requestData,
    submittedAt: new Date().toISOString(),
    status: "pending",
  };
  requests.push(request);
  localStorage.setItem(REQUESTS_KEY, JSON.stringify(requests));
  return request;
};

export const getBloodRequests = (): BloodRequest[] => {
  const stored = localStorage.getItem(REQUESTS_KEY);
  return stored ? JSON.parse(stored) : [];
};
