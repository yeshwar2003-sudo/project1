// Sample donor data for testing
// This will be automatically loaded on first visit

export const sampleDonors = [
  {
    fullName: "Rahul Sharma",
    email: "rahul.sharma@example.com",
    phone: "9876543210",
    bloodType: "O+",
    age: "28",
    weight: "65",
    city: "Andheri",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400058",
    lastDonation: "2024-11-15",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Priya Patel",
    email: "priya.patel@example.com",
    phone: "9876543211",
    bloodType: "A+",
    age: "26",
    weight: "55",
    city: "Bandra",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400050",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekends"
  },
  {
    fullName: "Amit Kumar",
    email: "amit.kumar@example.com",
    phone: "9876543212",
    bloodType: "B+",
    age: "32",
    weight: "70",
    city: "Powai",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400076",
    lastDonation: "2024-10-20",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Sneha Reddy",
    email: "sneha.reddy@example.com",
    phone: "9876543213",
    bloodType: "AB+",
    age: "24",
    weight: "52",
    city: "Juhu",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400049",
    lastDonation: "",
    medicalConditions: "",
    availability: "emergency"
  },
  {
    fullName: "Vikram Singh",
    email: "vikram.singh@example.com",
    phone: "9876543214",
    bloodType: "O-",
    age: "35",
    weight: "75",
    city: "Malad",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400064",
    lastDonation: "2024-09-05",
    medicalConditions: "",
    availability: "weekdays"
  },
  {
    fullName: "Anjali Desai",
    email: "anjali.desai@example.com",
    phone: "9876543215",
    bloodType: "A-",
    age: "29",
    weight: "58",
    city: "Dadar",
    district: "Mumbai",
    state: "Maharashtra",
    pincode: "400014",
    lastDonation: "2024-12-01",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Rajesh Verma",
    email: "rajesh.verma@example.com",
    phone: "9876543216",
    bloodType: "B-",
    age: "41",
    weight: "78",
    city: "Thane",
    district: "Thane",
    state: "Maharashtra",
    pincode: "400601",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekdays"
  },
  {
    fullName: "Kavita Joshi",
    email: "kavita.joshi@example.com",
    phone: "9876543217",
    bloodType: "AB-",
    age: "27",
    weight: "54",
    city: "Navi Mumbai",
    district: "Thane",
    state: "Maharashtra",
    pincode: "400706",
    lastDonation: "2024-08-15",
    medicalConditions: "",
    availability: "weekends"
  },
  {
    fullName: "Deepak Agarwal",
    email: "deepak.agarwal@example.com",
    phone: "9876543218",
    bloodType: "O+",
    age: "33",
    weight: "72",
    city: "Koramangala",
    district: "Bangalore",
    state: "Karnataka",
    pincode: "560034",
    lastDonation: "2024-10-10",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Meera Nair",
    email: "meera.nair@example.com",
    phone: "9876543219",
    bloodType: "A+",
    age: "25",
    weight: "50",
    city: "Indiranagar",
    district: "Bangalore",
    state: "Karnataka",
    pincode: "560038",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekends"
  },
  {
    fullName: "Suresh Iyer",
    email: "suresh.iyer@example.com",
    phone: "9876543220",
    bloodType: "B+",
    age: "38",
    weight: "68",
    city: "Whitefield",
    district: "Bangalore",
    state: "Karnataka",
    pincode: "560066",
    lastDonation: "2024-11-20",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Ritu Kapoor",
    email: "ritu.kapoor@example.com",
    phone: "9876543221",
    bloodType: "AB+",
    age: "30",
    weight: "56",
    city: "Connaught Place",
    district: "New Delhi",
    state: "Delhi",
    pincode: "110001",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekdays"
  },
  {
    fullName: "Arjun Mehta",
    email: "arjun.mehta@example.com",
    phone: "9876543222",
    bloodType: "O-",
    age: "36",
    weight: "80",
    city: "Dwarka",
    district: "South West Delhi",
    state: "Delhi",
    pincode: "110075",
    lastDonation: "2024-09-25",
    medicalConditions: "",
    availability: "emergency"
  },
  {
    fullName: "Pooja Shah",
    email: "pooja.shah@example.com",
    phone: "9876543223",
    bloodType: "A-",
    age: "28",
    weight: "53",
    city: "Satellite",
    district: "Ahmedabad",
    state: "Gujarat",
    pincode: "380015",
    lastDonation: "2024-12-05",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Karan Malhotra",
    email: "karan.malhotra@example.com",
    phone: "9876543224",
    bloodType: "B-",
    age: "31",
    weight: "74",
    city: "Prahlad Nagar",
    district: "Ahmedabad",
    state: "Gujarat",
    pincode: "380051",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekends"
  },
  {
    fullName: "Divya Krishnan",
    email: "divya.krishnan@example.com",
    phone: "9876543225",
    bloodType: "O+",
    age: "26",
    weight: "51",
    city: "Anna Nagar",
    district: "Chennai",
    state: "Tamil Nadu",
    pincode: "600040",
    lastDonation: "2024-10-30",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Sanjay Reddy",
    email: "sanjay.reddy@example.com",
    phone: "9876543226",
    bloodType: "A+",
    age: "34",
    weight: "76",
    city: "T Nagar",
    district: "Chennai",
    state: "Tamil Nadu",
    pincode: "600017",
    lastDonation: "",
    medicalConditions: "",
    availability: "weekdays"
  },
  {
    fullName: "Neha Gupta",
    email: "neha.gupta@example.com",
    phone: "9876543227",
    bloodType: "B+",
    age: "27",
    weight: "57",
    city: "Banjara Hills",
    district: "Hyderabad",
    state: "Telangana",
    pincode: "500034",
    lastDonation: "2024-11-10",
    medicalConditions: "",
    availability: "weekends"
  },
  {
    fullName: "Aditya Rao",
    email: "aditya.rao@example.com",
    phone: "9876543228",
    bloodType: "AB+",
    age: "29",
    weight: "69",
    city: "HITEC City",
    district: "Hyderabad",
    state: "Telangana",
    pincode: "500081",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Simran Kaur",
    email: "simran.kaur@example.com",
    phone: "9876543229",
    bloodType: "O-",
    age: "25",
    weight: "52",
    city: "Model Town",
    district: "Ludhiana",
    state: "Punjab",
    pincode: "141002",
    lastDonation: "2024-12-01",
    medicalConditions: "",
    availability: "emergency"
  },
  // New A+ donors added by user
  {
    fullName: "Sunitha C",
    email: "sunitha.c@example.com",
    phone: "9448281375",
    bloodType: "A+",
    age: "30",
    weight: "55",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560001",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Arun J Kumar",
    email: "arun.kumar@example.com",
    phone: "9845488113",
    bloodType: "A+",
    age: "32",
    weight: "70",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560002",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Sandeep Devaki",
    email: "sandeep.devaki@example.com",
    phone: "8121269312",
    bloodType: "A+",
    age: "28",
    weight: "68",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560003",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Suman S H",
    email: "suman.sh@example.com",
    phone: "9343754518",
    bloodType: "A+",
    age: "29",
    weight: "65",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560004",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Ali Mohammed",
    email: "ali.mohammed@example.com",
    phone: "9008066308",
    bloodType: "A+",
    age: "35",
    weight: "72",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560005",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Sanoj Thomas",
    email: "sanoj.thomas@example.com",
    phone: "9886772233",
    bloodType: "A+",
    age: "31",
    weight: "67",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560006",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Rakesh Sharan R",
    email: "rakesh.sharan@example.com",
    phone: "8123020307",
    bloodType: "A+",
    age: "33",
    weight: "73",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560007",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Pradeep",
    email: "pradeep@example.com",
    phone: "9972144992",
    bloodType: "A+",
    age: "27",
    weight: "64",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560008",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Priya Vignesh",
    email: "priya.vignesh@example.com",
    phone: "8971093958",
    bloodType: "A+",
    age: "26",
    weight: "52",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560009",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  },
  {
    fullName: "Mahesh Dhinge",
    email: "mahesh.dhinge@example.com",
    phone: "9741255223",
    bloodType: "A+",
    age: "34",
    weight: "69",
    city: "Bangalore",
    district: "Bangalore Urban",
    state: "Karnataka",
    pincode: "560010",
    lastDonation: "",
    medicalConditions: "",
    availability: "anytime"
  }
];

// Function to load sample data if no donors exist
export function loadSampleData() {
  // Check if we're in a browser environment
  if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
    return;
  }

  const DONORS_KEY = "lifelink_donors";
  const SAMPLE_LOADED_KEY = "lifelink_sample_loaded";

  try {
    // Check if sample data already loaded
    if (localStorage.getItem(SAMPLE_LOADED_KEY)) {
      return;
    }

    // Check if donors already exist
    const existing = JSON.parse(localStorage.getItem(DONORS_KEY) || '[]');
    if (existing.length > 0) {
      return;
    }

    // Load sample donors
    const donorsWithIds = sampleDonors.map((donor, index) => ({
      id: `donor:${Date.now() + index}:${Math.random().toString(36).substr(2, 9)}`,
      ...donor,
      registeredAt: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString(), // Random date within last 90 days
    }));

    localStorage.setItem(DONORS_KEY, JSON.stringify(donorsWithIds));
    localStorage.setItem(SAMPLE_LOADED_KEY, 'true');

    console.log(`✅ Loaded ${donorsWithIds.length} sample donors for testing!`);
  } catch (error) {
    console.error('Failed to load sample data:', error);
  }
}
