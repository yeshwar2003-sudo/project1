#!/bin/bash

# Deploy Supabase Edge Function
# Usage: ./deploy-edge-function.sh

set -e

echo "🚀 Deploying Supabase Edge Function..."
echo ""

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null
then
    echo "❌ Supabase CLI not found!"
    echo ""
    echo "Install it with:"
    echo "  npm install -g supabase"
    echo ""
    exit 1
fi

echo "✅ Supabase CLI found"
echo ""

# Check if logged in
echo "🔐 Checking authentication..."
if ! supabase projects list &> /dev/null
then
    echo "❌ Not logged in to Supabase"
    echo ""
    echo "Login with:"
    echo "  supabase login"
    echo ""
    exit 1
fi

echo "✅ Authenticated"
echo ""

# Deploy the function
echo "📦 Deploying make-server-07d11c75..."
echo ""

cd "$(dirname "$0")"

supabase functions deploy make-server-07d11c75 \
  --project-ref wlmjimdrkiqohudnurlw \
  --no-verify-jwt

echo ""
echo "✅ Deployment complete!"
echo ""
echo "🧪 Testing health endpoint..."
echo ""

HEALTH_URL="https://wlmjimdrkiqohudnurlw.supabase.co/functions/v1/make-server-07d11c75/health"
RESPONSE=$(curl -s "$HEALTH_URL")

if [ "$RESPONSE" == '{"status":"ok"}' ]; then
    echo "✅ Health check passed!"
    echo "Response: $RESPONSE"
else
    echo "⚠️  Unexpected response:"
    echo "Response: $RESPONSE"
fi

echo ""
echo "🎉 All done!"
echo ""
echo "Next steps:"
echo "  1. Test the app at your Figma Make URL"
echo "  2. Register a donor"
echo "  3. Check if blue notices are gone"
echo "  4. Data should now save to database"
echo ""
