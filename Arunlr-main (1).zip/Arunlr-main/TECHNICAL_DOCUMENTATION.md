# Technical Documentation - LifeLink Blood Donation Network

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Frontend Implementation](#frontend-implementation)
3. [Backend Implementation](#backend-implementation)
4. [Database Design](#database-design)
5. [API Reference](#api-reference)
6. [State Management](#state-management)
7. [Error Handling](#error-handling)
8. [Performance Optimization](#performance-optimization)
9. [Deployment Guide](#deployment-guide)
10. [Development Workflow](#development-workflow)

---

## Architecture Overview

### System Architecture

The application follows a three-tier architecture:

```
┌─────────────────────────────────────────┐
│         Presentation Layer              │
│    (React + TypeScript + Tailwind)      │
└──────────────┬──────────────────────────┘
               │
               │ REST API (HTTPS)
               │
┌──────────────▼──────────────────────────┐
│          Application Layer              │
│      (Supabase Edge Functions)          │
└──────────────┬──────────────────────────┘
               │
               │ Database Queries
               │
┌──────────────▼──────────────────────────┐
│           Data Layer                    │
│      (PostgreSQL + KV Store)            │
└─────────────────────────────────────────┘
```

### Technology Choices

**Frontend: React + TypeScript**
- Component-based architecture for reusability
- Type safety reduces runtime errors
- Large ecosystem and community support

**Styling: Tailwind CSS v4**
- Utility-first approach for rapid development
- Minimal CSS bundle size
- Consistent design system

**Backend: Supabase Edge Functions**
- Serverless architecture (no server management)
- Global edge network for low latency
- Built-in authentication and security

**Database: PostgreSQL with KV Store**
- ACID compliance for data integrity
- Efficient key-value storage pattern
- Scalable for future growth

---

## Frontend Implementation

### Component Architecture

#### 1. Page Components

**Home.tsx**
```typescript
// Landing page with hero section and features
- Hero with CTA buttons
- Statistics showcase
- Feature highlights
- Responsive image with fallback
```

**BecomeDonor.tsx**
```typescript
// Donor registration form
State Management:
- formData: Form field values
- submitted: Success state
- loading: API call state
- error: Error message state

Features:
- Multi-section form layout
- Field validation
- API integration
- Success confirmation
```

**FindDonors.tsx**
```typescript
// Donor search interface
State Management:
- bloodType: Selected blood type
- location: Search location
- donors: Search results array
- searched: Search executed flag
- loading: API call state
- error: Error message

Features:
- Filter-based search
- Dynamic results display
- Empty state handling
```

**RequestBlood.tsx**
```typescript
// Blood request submission
State Management:
- formData: Request details
- submitted: Success state
- loading: API call state
- error: Error message

Features:
- Emergency alert banner
- Comprehensive form
- Urgency level selection
```

#### 2. Layout Components

**Navbar.tsx**
```typescript
Features:
- Responsive navigation
- Mobile hamburger menu
- Active route highlighting
- Logo with image import
- Sticky positioning

Implementation:
const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
const location = useLocation();
const isActive = (path: string) => location.pathname === path;
```

**Footer.tsx**
```typescript
Features:
- Multi-column layout
- Quick links
- Contact information
- Responsive grid
- Logo display
```

### Routing Implementation

```typescript
// routes.ts
import { createBrowserRouter } from "react-router";

export const router = createBrowserRouter([
  { path: "/", Component: Home },
  { path: "/find-donors", Component: FindDonors },
  { path: "/become-donor", Component: BecomeDonor },
  { path: "/request-blood", Component: RequestBlood },
  { path: "/how-it-works", Component: HowItWorks },
  { path: "*", Component: NotFound },
]);
```

### Form Handling Pattern

```typescript
// Standard form handling across pages
const [formData, setFormData] = useState({
  field1: "",
  field2: "",
  // ... more fields
});

const handleChange = (
  e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
) => {
  setFormData({
    ...formData,
    [e.target.name]: e.target.value,
  });
};

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);
  setError("");
  
  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(formData),
    });
    
    const result = await response.json();
    
    if (result.success) {
      setSubmitted(true);
      // Reset form
    } else {
      setError(result.error);
    }
  } catch (err) {
    setError("Network error. Please try again.");
  } finally {
    setLoading(false);
  }
};
```

### API Integration

```typescript
// utils/supabase/info.tsx (Auto-generated)
export const projectId = "wlmjimdrkiqohudnurlw";
export const publicAnonKey = "eyJhbGciOiJ...";

// Usage in components
import { projectId, publicAnonKey } from "../../../utils/supabase/info";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-07d11c75`;

// POST request
const response = await fetch(`${API_BASE}/donors`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${publicAnonKey}`,
  },
  body: JSON.stringify(data),
});

// GET request with query params
const params = new URLSearchParams({ bloodType, location });
const response = await fetch(`${API_BASE}/donors?${params}`, {
  headers: { "Authorization": `Bearer ${publicAnonKey}` },
});
```

### Styling Patterns

```typescript
// Tailwind CSS utility classes

// Container
className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"

// Card
className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow"

// Button Primary
className="bg-red-600 text-white px-8 py-4 rounded-lg hover:bg-red-700 transition-colors font-semibold"

// Button Disabled
className="disabled:bg-gray-400 disabled:cursor-not-allowed"

// Form Input
className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"

// Grid Layout
className="grid md:grid-cols-2 gap-4"

// Flex Layout
className="flex items-center justify-between gap-4"
```

---

## Backend Implementation

### Edge Function Structure

```typescript
// supabase/functions/server/index.tsx

import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Middleware
app.use('*', logger(console.log));
app.use("/*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
}));

// Health check
app.get("/make-server-07d11c75/health", (c) => {
  return c.json({ status: "ok" });
});

// Start server
Deno.serve(app.fetch);
```

### API Endpoint Implementation

**Register Donor Endpoint**
```typescript
app.post("/make-server-07d11c75/donors", async (c) => {
  try {
    // Parse request body
    const donorData = await c.req.json();
    
    // Generate unique ID
    const donorId = `donor:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
    
    // Create donor object
    const donor = {
      id: donorId,
      ...donorData,
      registeredAt: new Date().toISOString(),
    };
    
    // Save to database
    await kv.set(donorId, donor);
    
    console.log(`Donor registered: ${donorId}`);
    
    return c.json({
      success: true,
      donor,
      message: "Donor registered successfully"
    });
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return c.json({ success: false, error: error.message }, 500);
  }
});
```

**Search Donors Endpoint**
```typescript
app.get("/make-server-07d11c75/donors", async (c) => {
  try {
    // Get query parameters
    const bloodType = c.req.query("bloodType");
    const location = c.req.query("location");
    
    // Fetch all donors
    const allDonors = await kv.getByPrefix("donor:");
    
    // Apply filters
    let filteredDonors = allDonors;
    
    if (bloodType) {
      filteredDonors = filteredDonors.filter(
        donor => donor.bloodType === bloodType
      );
    }
    
    if (location) {
      const locationLower = location.toLowerCase();
      filteredDonors = filteredDonors.filter(donor =>
        donor.city?.toLowerCase().includes(locationLower) ||
        donor.district?.toLowerCase().includes(locationLower) ||
        donor.state?.toLowerCase().includes(locationLower) ||
        donor.pincode?.includes(location)
      );
    }
    
    console.log(`Found ${filteredDonors.length} donors`);
    
    return c.json({ success: true, donors: filteredDonors });
  } catch (error) {
    return c.json({ success: false, error: error.message }, 500);
  }
});
```

**Submit Blood Request Endpoint**
```typescript
app.post("/make-server-07d11c75/blood-requests", async (c) => {
  try {
    const requestData = await c.req.json();
    const requestId = `request:${Date.now()}:${Math.random().toString(36).substr(2, 9)}`;
    
    const bloodRequest = {
      id: requestId,
      ...requestData,
      submittedAt: new Date().toISOString(),
      status: "pending",
    };
    
    await kv.set(requestId, bloodRequest);
    
    console.log(`Blood request submitted: ${requestId}`);
    
    return c.json({
      success: true,
      request: bloodRequest,
      message: "Blood request submitted successfully"
    });
  } catch (error) {
    return c.json({ success: false, error: error.message }, 500);
  }
});
```

### Database Client (KV Store)

```typescript
// supabase/functions/server/kv_store.tsx

import { createClient } from "jsr:@supabase/supabase-js@2.49.8";

const client = () => createClient(
  Deno.env.get("SUPABASE_URL"),
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"),
);

// Set a single key-value pair
export const set = async (key: string, value: any): Promise<void> => {
  const supabase = client();
  const { error } = await supabase
    .from("kv_store_07d11c75")
    .upsert({ key, value });
  if (error) throw new Error(error.message);
};

// Get a single value by key
export const get = async (key: string): Promise<any> => {
  const supabase = client();
  const { data, error } = await supabase
    .from("kv_store_07d11c75")
    .select("value")
    .eq("key", key)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data?.value;
};

// Search by key prefix
export const getByPrefix = async (prefix: string): Promise<any[]> => {
  const supabase = client();
  const { data, error } = await supabase
    .from("kv_store_07d11c75")
    .select("key, value")
    .like("key", prefix + "%");
  if (error) throw new Error(error.message);
  return data?.map(d => d.value) ?? [];
};

// Delete a key
export const del = async (key: string): Promise<void> => {
  const supabase = client();
  const { error } = await supabase
    .from("kv_store_07d11c75")
    .delete()
    .eq("key", key);
  if (error) throw new Error(error.message);
};
```

---

## Database Design

### Key-Value Store Pattern

The application uses a key-value store pattern on top of PostgreSQL:

```sql
CREATE TABLE kv_store_07d11c75 (
  key TEXT NOT NULL PRIMARY KEY,
  value JSONB NOT NULL
);
```

### Key Naming Convention

```
donor:{timestamp}:{random}
  Example: donor:1746533267890:abc123xyz

request:{timestamp}:{random}
  Example: request:1746533267890:xyz789abc
```

### Benefits of This Approach

1. **Schema Flexibility:** JSONB allows storing complex objects
2. **Fast Lookups:** Primary key on 'key' field
3. **Prefix Queries:** Efficient filtering with LIKE 'prefix%'
4. **Scalability:** Easy to partition by key prefix
5. **Version Control:** Can store schema version in value

### Query Patterns

```typescript
// Get single record
const donor = await kv.get("donor:1234567890:abc123");

// Get all donors
const allDonors = await kv.getByPrefix("donor:");

// Get all requests
const allRequests = await kv.getByPrefix("request:");

// Delete a record
await kv.del("donor:1234567890:abc123");
```

---

## API Reference

### Authentication

All API requests require an Authorization header:

```http
Authorization: Bearer {publicAnonKey}
```

### Response Format

**Success Response:**
```json
{
  "success": true,
  "data": { ... },
  "message": "Operation successful"
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Error message description"
}
```

### Endpoint Details

#### POST /donors

Register a new blood donor.

**Request:**
```http
POST /make-server-07d11c75/donors
Content-Type: application/json
Authorization: Bearer {publicAnonKey}

{
  "fullName": "Rahul Sharma",
  "email": "rahul@example.com",
  "phone": "9876543210",
  "bloodType": "O+",
  "age": "28",
  "weight": "65",
  "city": "Andheri",
  "district": "Mumbai",
  "state": "Maharashtra",
  "pincode": "400058",
  "lastDonation": "2024-11-15",
  "medicalConditions": "",
  "availability": "anytime"
}
```

**Response (200):**
```json
{
  "success": true,
  "donor": {
    "id": "donor:1746533267890:abc123xyz",
    "fullName": "Rahul Sharma",
    "email": "rahul@example.com",
    "phone": "9876543210",
    "bloodType": "O+",
    "age": "28",
    "weight": "65",
    "city": "Andheri",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400058",
    "lastDonation": "2024-11-15",
    "medicalConditions": "",
    "availability": "anytime",
    "registeredAt": "2025-05-06T10:30:00.000Z"
  },
  "message": "Donor registered successfully"
}
```

#### GET /donors

Search for blood donors with optional filters.

**Query Parameters:**
- `bloodType` (optional) - Filter by blood type (A+, A-, B+, B-, AB+, AB-, O+, O-)
- `location` (optional) - Search in city, district, state, or pincode

**Request:**
```http
GET /make-server-07d11c75/donors?bloodType=O+&location=Mumbai
Authorization: Bearer {publicAnonKey}
```

**Response (200):**
```json
{
  "success": true,
  "donors": [
    {
      "id": "donor:1746533267890:abc123xyz",
      "fullName": "Rahul Sharma",
      "bloodType": "O+",
      "city": "Andheri",
      "district": "Mumbai",
      "state": "Maharashtra",
      "phone": "9876543210",
      "email": "rahul@example.com",
      "availability": "anytime",
      "registeredAt": "2025-05-06T10:30:00.000Z"
    }
  ]
}
```

---

## State Management

### Component-Level State

The application uses React's built-in state management:

```typescript
// Form state
const [formData, setFormData] = useState<FormData>(initialState);

// UI state
const [loading, setLoading] = useState<boolean>(false);
const [error, setError] = useState<string>("");
const [submitted, setSubmitted] = useState<boolean>(false);

// Search state
const [donors, setDonors] = useState<Donor[]>([]);
const [searched, setSearched] = useState<boolean>(false);
```

### State Update Patterns

```typescript
// Object spread for form updates
setFormData(prev => ({
  ...prev,
  [fieldName]: value
}));

// Boolean toggles
setLoading(true);
setSubmitted(false);

// Array updates
setDonors(result.donors);

// Error handling
setError("Network error. Please try again.");
```

### Why No Global State?

The application doesn't require Redux or Context API because:
1. No shared state between unrelated components
2. API calls fetch fresh data when needed
3. Form state is page-specific
4. Simple parent-child data flow

---

## Error Handling

### Frontend Error Handling

```typescript
// Network error handling
try {
  const response = await fetch(url, options);
  const result = await response.json();
  
  if (result.success) {
    // Handle success
  } else {
    setError(result.error || "Operation failed");
  }
} catch (err) {
  console.error("Error:", err);
  setError("Network error. Please try again.");
} finally {
  setLoading(false);
}
```

### Backend Error Handling

```typescript
// Try-catch in endpoints
try {
  // Operation logic
  return c.json({ success: true, data });
} catch (error) {
  console.error(`Error: ${error.message}`);
  return c.json({ 
    success: false, 
    error: error.message 
  }, 500);
}
```

### User-Facing Error Messages

```typescript
// Display error in UI
{error && (
  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
    <p className="text-sm text-red-800">{error}</p>
  </div>
)}
```

---

## Performance Optimization

### Frontend Optimizations

1. **Code Splitting**
```typescript
// Routes automatically code-split with React Router
const router = createBrowserRouter([
  { path: "/", Component: Home },
  // Each component loads on demand
]);
```

2. **Image Optimization**
```typescript
// Using ImageWithFallback component
<ImageWithFallback
  src={imageUrl}
  alt="Description"
  className="w-full h-full object-cover"
/>
```

3. **Conditional Rendering**
```typescript
// Only render when needed
{searched && !loading && (
  <DonorResults donors={donors} />
)}
```

### Backend Optimizations

1. **Prefix Queries**
```typescript
// Efficient database queries
const donors = await kv.getByPrefix("donor:");
```

2. **Edge Functions**
- Deployed globally on Supabase edge network
- Low latency for all regions
- Auto-scaling based on demand

3. **Minimal Data Transfer**
```typescript
// Return only necessary fields
return c.json({
  success: true,
  donors: filteredDonors
});
```

---

## Deployment Guide

### Prerequisites

1. Figma Make account
2. Supabase project created
3. Git repository (optional)

### Deployment Steps

1. **Connect Supabase**
   - Click "Connect to Supabase" in Make
   - Authenticate with Supabase
   - Select/create project

2. **Deploy Edge Functions**
   - Functions auto-deploy when connected
   - Check deployment status in Supabase dashboard
   - Test endpoints via health check

3. **Frontend Deployment**
   - Build happens automatically in Make
   - No manual build step required
   - Preview available immediately

4. **Environment Variables**
   - Auto-configured by Make
   - Check `utils/supabase/info.tsx` for values
   - Never commit sensitive keys to git

### Post-Deployment

1. Test all features:
   - Donor registration
   - Blood request submission
   - Donor search
   - Mobile responsiveness

2. Monitor logs:
   - Supabase Edge Function logs
   - Browser console for errors
   - Network tab for API calls

3. Performance check:
   - Page load times
   - API response times
   - Mobile performance

---

## Development Workflow

### Local Development

```bash
# Install dependencies
pnpm install

# Start dev server
pnpm dev

# Build for production
pnpm build

# Preview production build
pnpm preview
```

### Code Structure

```
/src
  /app
    App.tsx              # Entry point
    routes.ts            # Route config
    /components          # Reusable components
    /pages              # Page components
  /imports              # Static assets
  /styles               # Global styles
/supabase
  /functions
    /server             # Backend code
/utils
  /supabase             # Supabase config
```

### Best Practices

1. **Component Organization**
   - One component per file
   - Named exports for components
   - Props interfaces defined above component

2. **Type Safety**
   - Define interfaces for all data structures
   - Use TypeScript strict mode
   - No 'any' types in production code

3. **Styling**
   - Use Tailwind utility classes
   - Extract repeated patterns to components
   - Maintain consistent spacing scale

4. **API Calls**
   - Always handle errors
   - Show loading states
   - Provide user feedback

5. **Git Workflow**
   - Commit frequently
   - Write descriptive commit messages
   - Keep commits focused and atomic

---

## Troubleshooting

### Common Issues

**Issue: API calls failing**
```
Solution: Check Supabase connection status
Verify publicAnonKey in utils/supabase/info.tsx
Check browser console for CORS errors
```

**Issue: Donor search returns empty**
```
Solution: Ensure donors are registered first
Check filter parameters
Verify database has data with correct keys
```

**Issue: Form validation not working**
```
Solution: Check input name attributes match formData keys
Verify pattern attributes for phone/pincode
Add required attributes to mandatory fields
```

**Issue: Mobile menu not closing**
```
Solution: Verify onClick handler on menu items
Check mobileMenuOpen state updates
Ensure setMobileMenuOpen(false) is called
```

---

## Maintenance

### Regular Tasks

1. **Monitor Database**
   - Check storage usage
   - Review query performance
   - Clean up test data

2. **Update Dependencies**
   - Keep React updated
   - Update Supabase client
   - Check for security patches

3. **Review Logs**
   - Edge function logs for errors
   - User feedback for issues
   - Analytics for usage patterns

4. **Backup Data**
   - Export database regularly
   - Store backups securely
   - Test restore procedures

---

## Support & Resources

- **Supabase Docs:** https://supabase.com/docs
- **React Docs:** https://react.dev
- **Tailwind Docs:** https://tailwindcss.com/docs
- **TypeScript Docs:** https://www.typescriptlang.org/docs

---

**Last Updated:** May 6, 2026  
**Version:** 1.0
