# Troubleshooting Guide

## Error: "Failed to fetch"

### Cause
The Supabase Edge Function is not deployed or not accessible.

### Solution

#### Option 1: Deploy via Supabase CLI (Recommended)

```bash
# 1. Install Supabase CLI
npm install -g supabase

# 2. Login
supabase login

# 3. Link your project
supabase link --project-ref wlmjimdrkiqohudnurlw

# 4. Deploy the function
cd supabase/functions
supabase functions deploy make-server-07d11c75 --project-ref wlmjimdrkiqohudnurlw
```

#### Option 2: Deploy via Figma Make Settings

1. Open your Figma Make project
2. Go to Settings → Supabase
3. Click "Deploy Edge Functions"
4. Wait for deployment to complete

#### Option 3: Redeploy from Dashboard

1. Go to https://supabase.com/dashboard/project/wlmjimdrkiqohudnurlw
2. Navigate to **Edge Functions** in sidebar
3. Look for `make-server-07d11c75` function
4. If it doesn't exist, create new function with the code from `/supabase/functions/server/index.tsx`
5. If it exists, click **Redeploy**

### Verify Deployment

Test the health endpoint:
```
https://wlmjimdrkiqohudnurlw.supabase.co/functions/v1/make-server-07d11c75/health
```

Expected response:
```json
{"status":"ok"}
```

---

## Error: "API Error: 404"

### Cause
The endpoint path is incorrect or function name doesn't match.

### Solution
1. Verify function name is exactly: `make-server-07d11c75`
2. Check Supabase dashboard for deployed function name
3. Update function name in code if different

---

## Error: "API Error: 401 Unauthorized"

### Cause
Invalid or missing authentication token.

### Solution
1. Check `/utils/supabase/info.tsx` has correct `publicAnonKey`
2. Verify Supabase project is active
3. Regenerate anon key in Supabase dashboard if needed

---

## Error: "API Error: 500 Internal Server Error"

### Cause
Server-side error in the edge function.

### Solution
1. Check Supabase Edge Function logs:
   - Go to Dashboard → Edge Functions → `make-server-07d11c75`
   - Click on "Logs" tab
   - Look for error messages

2. Common causes:
   - Database table doesn't exist
   - Invalid environment variables
   - Syntax error in server code

---

## Form Validation Errors

### Phone Number Validation Fails

**Issue:** Phone number not accepting input

**Solution:**
- Ensure 10-digit number without country code
- Example: `9876543210`
- Pattern: `[0-9]{10}`

### Pincode Validation Fails

**Issue:** Pincode not accepting input

**Solution:**
- Ensure 6-digit pincode
- Example: `400058`
- Pattern: `[0-9]{6}`

---

## Database Issues

### No Donors Found After Registration

**Cause:** Database not storing data or search filters too restrictive

**Debug Steps:**
1. Check browser console for errors
2. Verify API returned success response
3. Try searching without filters
4. Check Supabase database table: `kv_store_07d11c75`

### Search Returns Empty Results

**Cause:** No matching donors or incorrect search parameters

**Solution:**
1. Register a donor first
2. Search with exact blood type
3. Use partial city name (e.g., "Mum" for Mumbai)
4. Check console logs for API response

---

## Network Issues

### CORS Errors

**Issue:** Browser console shows CORS errors

**Solution:**
1. Verify CORS is enabled in edge function (should be by default)
2. Check if accessing from correct domain
3. Clear browser cache and cookies

### Slow API Response

**Issue:** Requests taking too long

**Possible Causes:**
- Cold start (first request after inactivity)
- Large dataset in database
- Network latency

**Solution:**
- First request may take 2-3 seconds (cold start)
- Subsequent requests should be fast
- Consider pagination for large datasets

---

## Browser Console Debugging

### Enable Detailed Logging

The app now logs detailed information to browser console:

```javascript
// What you'll see:
"Calling API: https://..."
"Response status: 200"
"Response data: {...}"
```

### How to View Logs

1. Open browser DevTools (F12)
2. Go to Console tab
3. Submit a form or search
4. Review logs for errors

---

## Quick Health Check

Run these checks to diagnose issues:

### 1. Check Supabase Connection
```
https://wlmjimdrkiqohudnurlw.supabase.co/functions/v1/make-server-07d11c75/health
```
✅ Should return: `{"status":"ok"}`

### 2. Check Donor Endpoint
Open browser console and run:
```javascript
fetch('https://wlmjimdrkiqohudnurlw.supabase.co/functions/v1/make-server-07d11c75/donors', {
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndsbWppbWRya2lxb2h1ZG51cmx3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc0Mzk0NDQsImV4cCI6MjA5MzAxNTQ0NH0.xXyOv8OXW1iX4nZ3woBnFjBQ99czpTyqJk28gDsQvl8'
  }
})
.then(r => r.json())
.then(console.log)
```
✅ Should return: `{"success":true,"donors":[]}`

### 3. Check Database Table
1. Go to Supabase Dashboard
2. Navigate to Table Editor
3. Look for `kv_store_07d11c75` table
4. Verify it exists and has correct schema

---

## Still Having Issues?

### Collect This Information:

1. **Browser Console Logs**
   - Screenshot of errors in Console tab
   - Network tab showing failed requests

2. **Supabase Edge Function Logs**
   - Dashboard → Edge Functions → Logs
   - Last 10 log entries

3. **Configuration**
   - Project ID: `wlmjimdrkiqohudnurlw`
   - Function name: `make-server-07d11c75`
   - Deployment status

4. **What You Tried**
   - Steps to reproduce the error
   - Forms that work/don't work
   - Browser and OS version

### Contact Support

- Supabase Support: https://supabase.com/support
- Figma Make Support: Via settings panel
- GitHub Issues: [Your repo]

---

## Prevention Tips

1. **Always Deploy After Changes**
   - After editing edge function code
   - Run deployment command
   - Verify deployment succeeded

2. **Test in Stages**
   - Test health endpoint first
   - Then test GET endpoints
   - Finally test POST endpoints

3. **Monitor Logs**
   - Check Supabase dashboard regularly
   - Watch for errors in browser console
   - Set up Supabase alerts for errors

4. **Keep Dependencies Updated**
   - Update Supabase client library
   - Update npm packages
   - Check for breaking changes

---

**Last Updated:** May 6, 2026
